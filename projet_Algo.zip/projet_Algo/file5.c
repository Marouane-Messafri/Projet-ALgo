#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

// Structure pour les étudiants

struct student {
    int id;
    char name[50];
    int age;
    char major[50];
};

struct course {
    int id;
    char title[100];
    int credits;
};

struct enrollment {
    int student_id;
    int course_id;
};


//Définition des structures pour l'arbre des étudiants 
typedef struct student_tree_node {
    struct student data;
    struct student_tree_node *left;
    struct student_tree_node *right;
} StudentNode;

//Définition des structures pour l'arbre des cours
typedef struct course_tree_node {
    struct course data;
    struct course_tree_node *left;
    struct course_tree_node *right;
} CourseNode;

//Définition des structures pour l'arbre des inscriptions
typedef struct enrollment_tree_node {
    struct enrollment data;
    struct enrollment_tree_node *left;
    struct enrollment_tree_node *right;
} EnrollmentNode;

//Initialisation des racines pour chaque arbre
StudentNode* studentRoot = NULL;
CourseNode* courseRoot = NULL;
EnrollmentNode* enrollmentRoot = NULL;
/////////////////////////////////////////////////////


#define MAX_LINE_LENGTH 1024

// Fonction pour lire des données d'un fichier CSV et les stocker dans une structure de données
void parse_students_csv(char* filename, struct student* students, int* count) {
    FILE* fp = fopen(filename, "r");
    if (fp == NULL) {
        printf("Impossible d'ouvrir le fichier %s.\n", filename);
        return;
    }
    
    char line[MAX_LINE_LENGTH];
    fgets(line, MAX_LINE_LENGTH, fp); // Ignore la première ligne d'en-tête
    while (fgets(line, MAX_LINE_LENGTH, fp)) {
        // Divise la ligne en champs séparés par des virgules
        char* token = strtok(line, ",");
        int i = 0;
        struct student new_student;
        while (token != NULL) {
            switch (i) {
                case 0: new_student.id = atoi(token); break;
                case 1: strcpy(new_student.name, token); break;
                case 2: new_student.age = atoi(token); break;
                case 3: strcpy(new_student.major, token); break;
            }
            token = strtok(NULL, ",");
            i++;
        }
        students[*count] = new_student;
        (*count)++;
    }
    fclose(fp);
}

// Fonction pour écrire des données d'une structure de données dans un fichier CSV
void serialize_students_csv(char* filename, struct student* students, int count) {
    FILE* fp = fopen(filename, "w");
    if (fp == NULL) {
        printf("Impossible d'écrire dans le fichier %s.\n", filename);
        return;
    }

    
    for (int i = 0; i < count; i++) {
        fprintf(fp, "%d,%s,%d,%s\n", students[i].id, students[i].name, students[i].age, students[i].major);
    }
    fclose(fp);
}


void parse_courses_csv(char* filename, struct course* courses, int* count) {
    FILE* file = fopen(filename, "r");

    if (file == NULL) {
        printf("Erreur lors de l'ouverture du fichier %s\n", filename);
        return;
    }

    char line[256];
    while (fgets(line, sizeof(line), file)) {
        int id;
        char title[100];
        int credits;

        
        sscanf(line, "%d,%[^,],%d", &id, title, &credits);
        struct course course = { id, {0}, credits };
        strcpy(course.title, title);
        courses[*count] = course;
        (*count)++;
    }

    fclose(file);
}

void parse_enrollments_csv(char* filename, struct enrollment* enrollments, int* count) {
    FILE* file = fopen(filename, "r");

    if (file == NULL) {
        printf("Erreur lors de l'ouverture du fichier %s\n", filename);
        return;
    }

    char line[256];
    while (fgets(line, sizeof(line), file)) {
        int student_id, course_id;

        sscanf(line, "%d,%d", &student_id, &course_id);

        struct enrollment enrollment = { student_id, course_id };
        enrollments[*count] = enrollment;
        (*count)++;
    }

    fclose(file);
}




void serialize_courses_csv(char* filename, struct course* courses, int count) {
    FILE* file = fopen(filename, "w");

    if (file == NULL) {
        printf("Erreur lors de l'ouverture du fichier %s\n", filename);
        return;
    }
    
    for (int i = 0; i < count; i++) {
        fprintf(file, "%d,%s,%d\n", courses[i].id, courses[i].title, courses[i].credits);
    }

    fclose(file);
}

void serialize_enrollments_csv(char* filename, struct enrollment* enrollments, int count) {
    FILE* file = fopen(filename, "w");

    if (file == NULL) {
        printf("Erreur lors de l'ouverture du fichier %s\n", filename);
        return;
    }
    
    for (int i = 0; i < count; i++) {
        fprintf(file, "%d,%d\n", enrollments[i].student_id, enrollments[i].course_id);
    }

    fclose(file);
}
// Insère un nouveau noeud dans l'arbre des étudiants
StudentNode* insertStudentNode(StudentNode* node, struct student s) {
    if (node == NULL) {
        StudentNode* new_node = (StudentNode*) malloc(sizeof(StudentNode));
        new_node->data = s;
        new_node->left = NULL;
        new_node->right = NULL;
        return new_node;
    } else if (s.id <= node->data.id) {
        node->left = insertStudentNode(node->left, s);
    } else {
        node->right = insertStudentNode(node->right, s);
    }

    return node;
}

// Insère un nouveau noeud dans l'arbre des cours
CourseNode* insertCourseNode(CourseNode* node, struct course c) {
    if (node == NULL) {
        CourseNode* new_node = (CourseNode*) malloc(sizeof(CourseNode));
        new_node->data = c;
        new_node->left = NULL;
        new_node->right = NULL;
        return new_node;
    } else if (c.id <= node->data.id) {
        node->left = insertCourseNode(node->left, c);
    } else {
        node->right = insertCourseNode(node->right, c);
    }

    return node;
}

// Insère un nouveau noeud dans l'arbre des inscriptions
EnrollmentNode* insertEnrollmentNode(EnrollmentNode* node, struct enrollment e) {
    if (node == NULL) {
        EnrollmentNode* new_node = (EnrollmentNode*) malloc(sizeof(EnrollmentNode));
        new_node->data = e;
        new_node->left = NULL;
        new_node->right = NULL;
        return new_node;
    } else if (e.student_id <= node->data.student_id) {
        node->left = insertEnrollmentNode(node->left, e);
    } else {
        node->right = insertEnrollmentNode(node->right, e);
    }

    return node;
}

// Écrit les données de chaque étudiant dans le fichier CSV
void serializeStudents(StudentNode* node, FILE* fp) {
    if (node != NULL) {
        fprintf(fp, "%d,%s,%d,%s\n", node->data.id, node->data.name, node->data.age, node->data.major);
        serializeStudents(node->left, fp);
        serializeStudents(node->right, fp);
    }
}

// Écrit les données de chaque cours dans le fichier CSV
void serializeCourses(CourseNode* node, FILE* fp) {
    if (node != NULL) {
        fprintf(fp, "%d,%s,%d\n", node->data.id, node->data.title, node->data.credits);
        serializeCourses(node->left, fp);
        serializeCourses(node->right, fp);
    }
}

// Écrit les données de chaque inscription dans le fichier CSV
void serializeEnrollments(EnrollmentNode* node, FILE* fp) {
    if (node != NULL) {
        fprintf(fp, "%d,%d\n", node->data.student_id, node->data.course_id);
        serializeEnrollments(node->left, fp);
        serializeEnrollments(node->right, fp);
    }
}




// Lit les données des étudiants depuis un fichier CSV et stocke les étudiants dans un arbre binaire
StudentNode* parseStudentCSV(char* filename) {
    FILE* fp = fopen(filename, "r");
    if (fp == NULL) {
        printf("Erreur lors de l'ouverture du fichier %s\n", filename);
        exit(1);
    }

    // Lecture de chaque ligne du fichier CSV et stockage dans l'arbre binaire
    StudentNode* root = NULL;
    char line[1024];
    while (fgets(line, 1024, fp)) {
        struct student s;
        sscanf(line, "%d,%[^,],%d,%[^\n]", &s.id, s.name, &s.age, s.major);
        root = insertStudentNode(root, s);
    }

    fclose(fp);
    return root;
}

// Lit les données des cours depuis un fichier CSV et stocke les cours dans un arbre binaire
CourseNode* parseCourseCSV(char* filename) {
    FILE* fp = fopen(filename, "r");
    if (fp == NULL) {
        printf("Erreur lors de l'ouverture du fichier %s\n", filename);
        exit(1);
    }

    // Lecture de chaque ligne du fichier CSV et stockage dans l'arbre binaire
    CourseNode* root = NULL;
    char line[1024];
    while (fgets(line, 1024, fp)) {
        struct course c;
        sscanf(line, "%d,%[^,],%d", &c.id, c.title, &c.credits);
        root = insertCourseNode(root, c);
    }

    fclose(fp);
    return root;
}

// Lit les données des inscriptions depuis un fichier CSV et stocke les inscriptions dans un arbre binaire
EnrollmentNode* parseEnrollmentCSV(char* filename) {
    FILE* fp = fopen(filename, "r");
    if (fp == NULL) {
        printf("Erreur lors de l'ouverture du fichier %s\n", filename);
        exit(1);
    }

    // Lecture de chaque ligne du fichier CSV et stockage dans l'arbre binaire
    EnrollmentNode* root = NULL;
    char line[1024];
    while (fgets(line, 1024, fp)) {
        struct enrollment e;
        sscanf(line, "%d,%d", &e.student_id, &e.course_id);
        root = insertEnrollmentNode(root, e);
    }

    fclose(fp);
    return root;
}

// Écrit les données des étudiants dans un fichier CSV
void serializeStudentCSV(StudentNode* node, char* filename) {
    FILE* fp = fopen(filename, "w");
    if (fp == NULL) {
        printf("Erreur lors de l'ouverture du fichier %s\n", filename);
        exit(1);
    }

    // Écriture des données de chaque étudiant dans le fichier CSV
    serializeStudents(node, fp);

    fclose(fp);
}

// Écrit les données des cours dans un fichier CSV
void serializeCourseCSV(CourseNode* node, char* filename) {
    FILE* fp = fopen(filename, "w");
    if (fp == NULL) {
        printf("Error opening file %s\n", filename);
        exit(1);
    }

    // Écriture des données de chaque cours dans le fichier CSV
    serializeCourses(node, fp);

    fclose(fp);
}

// Écrit les données des inscriptions dans un fichier CSV
void serializeEnrollmentCSV(EnrollmentNode* node, char* filename) {
    FILE* fp = fopen(filename, "w");
    if (fp == NULL) {
        printf("Erreur lors de l'ouverture du fichier %s\n", filename);
        exit(1);
    }

    // Écriture des données de chaque inscription dans le fichier CSV
    serializeEnrollments(node, fp);

    fclose(fp);
}

// Supprime tous les noeuds de l'arbre des étudiants et libère la mémoire allouée
void destroyStudentTree(StudentNode* node) {
    if (node != NULL) {
        destroyStudentTree(node->left);
        destroyStudentTree(node->right);
        free(node);
    }
}

// Supprime tous les noeuds de l'arbre des cours et libère la mémoire allouée
void destroyCourseTree(CourseNode* node) {
    if (node != NULL) {
        destroyCourseTree(node->left);
        destroyCourseTree(node->right);
        free(node);
    }
}

// Supprime tous les noeuds de l'arbre des inscriptions et libère la mémoire allouée
void destroyEnrollmentTree(EnrollmentNode* node) {
    if (node != NULL) {
        destroyEnrollmentTree(node->left);
        destroyEnrollmentTree(node->right);
        free(node);
    }
}
// Charge les données à partir des fichiers CSV et les stocke dans les arbres binaires de recherche
void load(char* students_filename, char* courses_filename, char* enrollments_filename) {
    // Charge les données des fichiers CSV dans les arbres binaires de recherche correspondants
    studentRoot = parseStudentCSV(students_filename);
    courseRoot = parseCourseCSV(courses_filename);
    enrollmentRoot = parseEnrollmentCSV(enrollments_filename);
    printf("Les données ont été chargées avec succès à partir des fichiers CSV.\n");
}

void save(char* students_filename, char* courses_filename, char* enrollments_filename, struct student* students, int student_count, struct course* courses, int course_count, struct enrollment* enrollments, int enrollment_count) {
    // Ajoute les nouvelles données aux arbres binaires de recherche
    for (int i = 0; i < student_count; i++) {
        studentRoot = insertStudentNode(studentRoot, students[i]);
    }
    for (int i = 0; i < course_count; i++) {
        courseRoot = insertCourseNode(courseRoot, courses[i]);
    }
    for (int i = 0; i < enrollment_count; i++) {
        enrollmentRoot = insertEnrollmentNode(enrollmentRoot, enrollments[i]);
    }

    // Enregistre les données dans les fichiers CSV
    serializeStudentCSV(studentRoot, students_filename);
    serializeCourseCSV(courseRoot, courses_filename);
    serializeEnrollmentCSV(enrollmentRoot, enrollments_filename);

    printf("Les modifications apportées ont été enregistrées avec succès dans les fichiers CSV.\n");
}

void clos() {
    // Libère la mémoire allouée pour les arbres binaires de recherche
    destroyStudentTree(studentRoot);
    studentRoot = NULL;
    destroyCourseTree(courseRoot);
    courseRoot = NULL;
    destroyEnrollmentTree(enrollmentRoot);
    enrollmentRoot = NULL;
    printf("La base de données a été fermée et toutes les ressources de mémoire ont été libérées.\n");
}





// Commandes CRUD étudiants

/*void insert_student(int id, char *name, int age, char *major) {

  struct student s;
  s.id = id;
  strcpy(s.name, name);
  s.age = age;
  strcpy(s.major, major);
  
  studentRoot = insertStudentNode(studentRoot, s);
  
  printf("Nouvel étudiant %s inséré\n", name);

}

void select_students(char *criteria) {

  searchAndPrintStudents(studentRoot, criteria); 

}

void delete_students(char *criteria) {

  deleteStudents(studentRoot, criteria);
  
  printf("Étudiants correspondant à %s supprimés\n", criteria);

}


*/



/*int main() {
    int ajoute = 0;
    char je_veux[10];
    struct student students[1000];
    int student_count = 0;
    struct course courses[100];
    int course_count = 0;
    struct enrollment enrollments[1000];
    int enrollment_count = 0;

    // Appel à la fonction load pour charger les données dans les arbres binaires de recherche
   // load("students.csv", "courses.csv", "enrollments.csv");

    // Lecture des données à partir du clavier
    printf("Enter student data as id,name,age,major:\n");
    while ((student_count < 1000)&&(ajoute==0)) {
        scanf("%d,%19[^,],%d,%9s", &students[student_count].id, students[student_count].name, &students[student_count].age, students[student_count].major) ;
            student_count++;
            fflush(stdin);
            printf("Vous voulez ajouter un autre étudiant (o/n): ");
            fgets(je_veux, sizeof(je_veux), stdin);
            if (je_veux[0] == 'n' || je_veux[0] == 'N') 
                ajoute = 1;
        }
        
    

    ajoute = 0;
    printf("Enter course data as id,title,credits:\n");
    while ((course_count < 1000)&&(ajoute==0)) {
        scanf("%d,%19[^,],%d", &courses[course_count].id, courses[course_count].title, &courses[course_count].credits);
            course_count++;
            fflush(stdin);
            printf("Vous voulez ajouter une autre course (o/n): ");
            fgets(je_veux, sizeof(je_veux), stdin);
            if (je_veux[0] == 'n' || je_veux[0] == 'N')
                ajoute = 1;
        }
        

    ajoute = 0;
    printf("Enter enrollments data as student_id,course_id:\n");
    while ((enrollment_count < 1000)&&(ajoute==0)) {
        scanf("%d,%d", &enrollments[enrollment_count].student_id, &enrollments[enrollment_count].course_id);
            enrollment_count++;
            fflush(stdin);
            printf("Vous voulez ajouter une autre inscription (o/n): ");
            fgets(je_veux, sizeof(je_veux), stdin);
            if (je_veux[0] == 'n' || je_veux[0] == 'N')
                ajoute = 1;
        }

    // Appel à la fonction save pour sauvegarder les données dans les fichiers CSV
    //save("students.csv", "courses.csv", "enrollments.csv");

    // Appel à la fonction close pour fermer la base de données et libérer la mémoire
  //  close();

    return 0;
}*/






















int main() {
    int ajoute = 0;
    char je_veux[10];
    struct student students[1000];
    int student_count = 0;
    struct course courses[100];
    int course_count = 0;
    struct enrollment enrollments[1000];
    int enrollment_count = 0;
    load("students.csv", "courses.csv", "enrollments.csv");
    // Lecture des données à partir du clavier
    printf("Enter student data as id,name,age,major:\n");
    while ((student_count < 1000)&&(ajoute==0)) {
        scanf("%d,%19[^,],%d,%9s", &students[student_count].id, students[student_count].name, &students[student_count].age, students[student_count].major) ;
            student_count++;
            fflush(stdin);
            printf("Vous voulez ajouter un autre étudiant (o/n): ");
            fgets(je_veux, sizeof(je_veux), stdin);
            if (je_veux[0] == 'n' || je_veux[0] == 'N') 
                ajoute = 1;
        }
        
    

    ajoute = 0;
    printf("Enter course data as id,title,credits:\n");
    while ((course_count < 1000)&&(ajoute==0)) {
        scanf("%d,%19[^,],%d", &courses[course_count].id, courses[course_count].title, &courses[course_count].credits);
            course_count++;
            fflush(stdin);
            printf("Vous voulez ajouter une autre course (o/n): ");
            fgets(je_veux, sizeof(je_veux), stdin);
            if (je_veux[0] == 'n' || je_veux[0] == 'N')
                ajoute = 1;
        }
        

    ajoute = 0;
    printf("Enter enrollments data as student_id,course_id:\n");
    while ((enrollment_count < 1000)&&(ajoute==0)) {
        scanf("%d,%d", &enrollments[enrollment_count].student_id, &enrollments[enrollment_count].course_id);
            enrollment_count++;
            fflush(stdin);
            printf("Vous voulez ajouter une autre inscription (o/n): ");
            fgets(je_veux, sizeof(je_veux), stdin);
            if (je_veux[0] == 'n' || je_veux[0] == 'N')
                ajoute = 1;
        }


    // Enregistrement des données dans les fichiers CSV
    serialize_students_csv("students.csv", students, student_count);
    serialize_courses_csv("courses.csv", courses, course_count);
    serialize_enrollments_csv("enrollments.csv", enrollments, enrollment_count);

    save("students.csv", "courses.csv", "enrollments.csv", students, student_count, courses, course_count, enrollments, enrollment_count);
    clos();
    return 0;
}





/*

int main() {
    printf("hi1");
    struct student students[1000];
    int student_count = 0;
    parse_students_csv("students.csv", students, &student_count);

    struct course courses[100];
    int course_count = 0;
    parse_courses_csv("courses.csv", courses, &course_count);

    struct enrollment enrollments[1000];
    int enrollment_count = 0;
    parse_enrollments_csv("enrollments.csv", enrollments, &enrollment_count);

    // Ajout d'une nouvelle inscription
    enrollments[enrollment_count].student_id = 55;  // ID de l'étudiant
    enrollments[enrollment_count].course_id = 12;   // ID du cours
    enrollment_count++;

    // Enregistrement des données mises à jour dans les fichiers CSV
    serialize_students_csv("students.csv", students, student_count);
    serialize_courses_csv("courses.csv", courses, course_count);
    serialize_enrollments_csv("enrollments.csv", enrollments, enrollment_count);

    return 0;
}*/